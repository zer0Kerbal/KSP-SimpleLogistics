# Simple Logistics Restocked
KSP Simple Logistics
Simple resource sharing among landed vessels.
by RealGecko

## Requirements
- Module Manager

## Changelog
### Version 2.0.3.0
- Recompile for KSP 1.7.3
- Code clean, update pass
- moved Changelog into separate file

### Version 2.0.2.1 recompile by forum user @Miracle Magician
- Recompile for KSP 1.7.2

### Version 2.0.2.0 recompile by forum user @Usgiyi
- Recompile for KSP 1.4.5

### Version 2.0.2
- Recompile for KSP 1.3.1

### Version 2.0.1
- Fixed MM patch

## Dependencies 
 * Kerbal Space Program
 * 
 
## Supports 
 * [WIP] Stock Mining Enhancements
 * [WIP] Near Future Electionics
 * [WIP] Bon Voyage
 
## Suggests 
 * 
 * 
 
## License 

*a part of the **TWYLLTR** (Take What You Like, Leave the Rest) collection.*  
 
📌v2.0.3.0-alpha  
 
## links to original:  


![Jeb's Rule #1"](https://ic.pics.livejournal.com/asaratov/25113347/1448500/1448500_original.jpg   "Jeb's Rule #1") 
 
 
 
##### All bundled mods are distributed under their own licenses
##### All art assets (textures, models, animations) are distributed under an All Rights Reserved License.

###### v2.0.2.2 original: 11 Aug 2018 0K updated: 17 Aug 2019 zed'K